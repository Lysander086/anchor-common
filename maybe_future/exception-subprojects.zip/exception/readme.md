Designed to auto generate code in the given directory. 
